package my.edu.utar;

import java.util.*;

public class WaitingList 
{
	private ArrayList <User> VIP;  // Array to store VIP member in waiting list
	private ArrayList <User> normal;  // Array to store normal member in waiting list
	private ArrayList <User> non;  // Array to store non-member in waiting list

	public WaitingList() 
	{
		this.VIP = new ArrayList <User> ();
		this.normal = new ArrayList <User> ();
		this.non = new ArrayList <User> ();
	}

	// Method to add a user to the appropriate waiting list based on member type
	public void addWaitingList(User user) 
	{
		if (user.getMemberType().equals("VIP")) 
		{
			VIP.add(user);
		} 

		else if (user.getMemberType().equals("normal")) 
		{
			normal.add(user);
		} 

		else if(user.getMemberType().equals("non"))
		{
			non.add(user);
		}
		
		else {
			throw new IllegalArgumentException("Invalid member type");
		}
	}

	// Method to remove a user from a waiting list (list not specified)
	public void removeWaitingList(User user) 
	{
		if (VIP.contains(user)) 
		{
			VIP.remove(user);
		} 

		else if (normal.contains(user)) 
		{
			normal.remove(user);
		} 

		else 
		{
			non.remove(user);
		}
	}

	// Method to get users from a specific waiting list (list not specified)
	public ArrayList <User> getWaitingList() 
	{
		if (!VIP.isEmpty()) 
		{
			return VIP;
		} 

		else if (!normal.isEmpty())
		{
			return normal;
		} 

		else {
			return non;
		}
	}
	
	public ArrayList<User>getVIP(){
		return VIP;
	}
	
	public ArrayList<User>getNormal(){
		return normal;
	}
	
	public ArrayList<User>getNon(){
		return non;
	}
}
