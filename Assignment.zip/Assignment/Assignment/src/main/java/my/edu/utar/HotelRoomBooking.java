package my.edu.utar;

import java.io.*;
import java.util.*;

class FileReaderClass
{
	public ArrayList <User> readFile(File file)
	{
		User user;
		ArrayList <User> list = new ArrayList <> ();
		
		try 
		{
			Scanner scanner = new Scanner(file);
			
			while (scanner.hasNext()) 
			{
				String [] tempList = scanner.nextLine().split(",");
				String name = tempList[0];
				String memberType = tempList[1];
				
				user = new User (name, memberType, false);
				
				list.add(user);
			}
		
			scanner.close();
		} 
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		return list;
	}
}

public class HotelRoomBooking
{
	Booking booking;
	Printer printer;
	Room room;
	User user;
	WaitingList wl;
	
	// To read user data from text file, and return an array list of User
	static FileReaderClass frc = new FileReaderClass ();
	static File file = new File ("userData.txt");
	static ArrayList <User> userList = frc.readFile(file);
	
	// Constructor
	public HotelRoomBooking()
	{
		user = new User("", "", false);
	}
	
	public HotelRoomBooking (User user)
	{
		this.user = user;
	}
	
	// To randomly set exclusive rewards for user
	public void randomSetRewards(ArrayList <User> userList)
	{
		Random random = new Random();
		
		for (int i = 0; i < userList.size(); i++)
		{
			// 1 - 100
			int ran = random.nextInt(1000);
			
			// P(Reward) = 143/1000 = 14.3%
			if (userList.get(i).getMemberType().equals("normal") && ran % 7 == 0)
			{
				userList.get(i).setReward(true);
			}	
		}
	}
	
	// To search for user, and return the index number
	public int searchUser(ArrayList <User> userList, String name)
	{
		int index = -1;
		
		for (int i = 0; i < userList.size(); i++)
		{
			if (userList.get(i).getName().equals(name))
			{
				index = i;
			}
		}
		
		return index;
	}
	
	// To add every user into waiting list before they can book a room
	public void addToWaitingList (ArrayList <User> userList)
	{
		for (int i = 0; i < userList.size(); i++)
		{
			wl.addWaitingList(userList.get(i));
		}
	}
	
	public static void main (String [] args)
	{
//		// to print the userList
//		for (int i = 0; i < userList.size(); i++)
//		{
//			System.out.println(userList.get(i).getName());
//			System.out.println(userList.get(i).getMemberType());
//			System.out.println(userList.get(i).getReward());
//			System.out.println();
//		}
		
		// to print the reward for normal user after invoking randomSetRewards()
		// need to set this method to static first
//		randomSetRewards(userList);
//		for (int i = 0; i < userList.size(); i++)
//		{
//			if (userList.get(i).getMemberType().equals("normal"))
//			{
//				System.out.println(userList.get(i).getName());
//				System.out.println(userList.get(i).getMemberType());
//				System.out.println(userList.get(i).getReward());
//				System.out.println();
//			}	
//		}
		
	}
}