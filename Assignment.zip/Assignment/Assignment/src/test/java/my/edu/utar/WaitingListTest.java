package my.edu.utar;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.runner.RunWith;


@RunWith(JUnitParamsRunner.class)
public class WaitingListTest {

	@Test
	@Parameters({"Joe,VIP,false"})
	public void testVIPWaitingList(String name,String membertype,boolean reward) {
		User user= mock(User.class);
		when(user.getName()).thenReturn(name);
		when(user.getMemberType()).thenReturn(membertype);
		WaitingList wl = new WaitingList();
		wl.addWaitingList(user);
		assertFalse(wl.getVIP().isEmpty());
		assertTrue(wl.getNormal().isEmpty());
		assertTrue(wl.getNon().isEmpty());
	}
	
	@Test
	@Parameters({"Joe,normal,false"})
	public void testNormalWaitingList(String name,String membertype,boolean reward) {
		User user= mock(User.class);
		when(user.getName()).thenReturn(name);
		when(user.getMemberType()).thenReturn(membertype);
		WaitingList wl = new WaitingList();
		wl.addWaitingList(user);
		assertFalse(wl.getNormal().isEmpty());
		assertTrue(wl.getVIP().isEmpty());
		assertTrue(wl.getNon().isEmpty());
	}
	
	@Test
	@Parameters({"Joe,non,false"})
	public void testNonWaitingList(String name,String membertype,boolean reward) {
		User user= mock(User.class);
		when(user.getName()).thenReturn(name);
		when(user.getMemberType()).thenReturn(membertype);
		WaitingList wl = new WaitingList();
		wl.addWaitingList(user);
		assertFalse(wl.getNon().isEmpty());
		assertTrue(wl.getVIP().isEmpty());
		assertTrue(wl.getNormal().isEmpty());
	}

}
