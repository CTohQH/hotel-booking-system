package my.edu.utar;

public class Booking
{
	private Room room;
	private WaitingList waitingList;
	private Printer printer;

	public Booking(Room room, WaitingList waitingList, Printer printer) 
	{
		this.room = room;
		this.waitingList = waitingList;
		this.printer = printer;
	}

	public void setBooking(User user) 
	{
		// To determine the room type for the user
		String roomType = getRoomType(user.getMemberType());
		// To check user is Normal Member && has reward
		if (user.getMemberType() == "Normal" && user.getReward() == true)
		{
			// To check availability of VIP room
			// if true, then only set roomType = VIP, and set reward = false
			if (room.checkRoom("VIP"))
			{
				roomType = "VIP";
				user.setReward(false);
			}
		}

		// To check room availability
		boolean roomAvailable = room.checkRoom(roomType);

		if (!roomAvailable && user.getMemberType()=="VIP") {
	        if ("VIP".equals(roomType)) {
	            // If VIP room not available, try Deluxe
	            roomType = "Deluxe";
	            roomAvailable = room.checkRoom(roomType);
	        }
	        if (!roomAvailable) {
	            // If Deluxe room not available, try Standard
	            roomType = "Standard";
	            roomAvailable = room.checkRoom(roomType);
	        }
	    }
		if(!roomAvailable && user.getMemberType()=="Normal") {
	           	roomType = "Standard";
	            roomAvailable = room.checkRoom(roomType);
	        
			
		}
		if (roomAvailable) {
	        room.bookRoom(roomType);
	        printer.printInfo(user.getName(), user.getMemberType(), roomType);
	    } else {
	        waitingList.addWaitingList(user);
	        System.out.println("Room not available. Added to waiting list.");
	    }
	}

	public void cancelBooking(User user)
	{
		String roomType = getRoomType(user.getMemberType());

		room.cancelBooking(roomType);
		waitingList.removeWaitingList(user);

		System.out.println("Booking cancelled successfully.");
	}

	public String getRoomType(String userType) 
	{
		switch (userType) 
		{
		case "VIP":
			return "VIP";
		case "Normal":
			return "Deluxe";
		default:
			return "Standard";
		}
	}
}
