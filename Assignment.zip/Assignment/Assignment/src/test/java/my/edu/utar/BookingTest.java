package my.edu.utar;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.*;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.runner.RunWith;


@RunWith(JUnitParamsRunner.class)
public class BookingTest {

    private Room room;
    private WaitingList waitingList;
    private Printer printer;
    private Booking booking;

    @Before
    public void setUp() {
        room = mock(Room.class);
        waitingList = mock(WaitingList.class);
        printer = mock(Printer.class);
        booking = new Booking(room, waitingList, printer);
    }
    
    @Test
    @Parameters({"true,true,true,true,VIP", "true,false,true,true,Deluxe","false,true,true,true,Deluxe","true,false,false,true,Standard"})
    public void testSetBookingNormal(boolean reward, boolean roomAvailVIP,boolean roomAvailDeluxe,boolean roomAvailStandard, String bookroom) {
        // Mock user
        User user = mock(User.class);
        when(user.getMemberType()).thenReturn("Normal");
        when(user.getReward()).thenReturn(reward);
        when(room.checkRoom("VIP")).thenReturn(roomAvailVIP);
        when(room.checkRoom("Deluxe")).thenReturn(roomAvailDeluxe);
        when(room.checkRoom("Standard")).thenReturn(roomAvailStandard);

        booking.setBooking(user);
        verify(room).bookRoom(bookroom);
    }
    
    @Test
    @Parameters({"true,true,VIP"})
    public void testSetBookingNormal2Room(boolean reward, boolean roomAvail, String bookroom) {
        // Mock user
        User user = mock(User.class);
        when(user.getMemberType()).thenReturn("Normal");
        when(user.getReward()).thenReturn(reward).thenReturn(false);
        when(room.checkRoom("VIP")).thenReturn(roomAvail);
        when(room.checkRoom("Deluxe")).thenReturn(roomAvail);
        booking.setBooking(user);

        if (roomAvail && "VIP".equals(bookroom)) {
            verify(room).bookRoom("VIP");
            verify(user).setReward(false);
        } else {
            verify(waitingList).addWaitingList(user);
            verifyNoMoreInteractions(printer);
        }
        
        booking.setBooking(user);
        verify(room).bookRoom("Deluxe");
        
    }
    
    
    @Test
    @Parameters({"true,true,true,VIP", "false,true,true,Deluxe","false,false,true,Standard"})
    public void testSetBookingVIP(boolean roomAvailVIP,boolean roomAvailDeluxe,boolean roomAvailStandard, String bookroom) {
        // Mock user
        User user = mock(User.class);
        when(user.getMemberType()).thenReturn("VIP");
        when(room.checkRoom("VIP")).thenReturn(roomAvailVIP);
        when(room.checkRoom("Deluxe")).thenReturn(roomAvailDeluxe); // Ensure Deluxe room not available
        when(room.checkRoom("Standard")).thenReturn(roomAvailStandard); // Ensure Standard room not available

        booking.setBooking(user);
        verify(room).bookRoom(bookroom);
    }
    
    @Test
    @Parameters({"true,Standard"})
    public void testSetBookingNonMember(boolean roomAvailStandard,String bookroom) {
    	User user = mock(User.class);
        when(user.getMemberType()).thenReturn("Non");
        when(room.checkRoom("Standard")).thenReturn(roomAvailStandard);
        
        //test set booking and verify the booked room
        booking.setBooking(user);
        verify(room).checkRoom("Standard");
        verify(room).bookRoom("Standard");
    }
    
    @Test
    @Parameters({"false,Standard"})
    public void testSetBookingNonMemberStandardNotAvail(boolean roomAvailStandard,String bookroom) {
    	User user = mock(User.class);
        when(user.getMemberType()).thenReturn("Non");
        when(room.checkRoom("Standard")).thenReturn(roomAvailStandard);
        
        //test set booking and verify the room not available then add to waitingList
        booking.setBooking(user);
        verify(room).checkRoom("Standard");
        verify(waitingList).addWaitingList(user);
    }

}
