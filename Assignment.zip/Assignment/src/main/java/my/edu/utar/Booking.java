package my.edu.utar;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

class FileReaderClass {
    // Reads user data from a file and returns a list of User objects
    public ArrayList<User> readFile(File file) {
        // Check if the file exists or is null
        if (file == null || !file.exists()) {
            throw new IllegalArgumentException("File does not exist or is null!");
        }

        ArrayList<User> list = new ArrayList<>();

        try (Scanner scanner = new Scanner(file)) {
            // Read each line of the file
            while (scanner.hasNext()) {
                // Split each line by comma to extract user data
                String[] tempList = scanner.nextLine().split(",");
                // Check if user data format is valid
                if (tempList.length != 2) {
                    throw new IllegalArgumentException("Invalid user data format in file!");
                }
                // Extract name and member type from the line
                String name = tempList[0];
                String memberType = tempList[1];

                // Create a new User object and add it to the list
                User user = new User(name, memberType, false);
                list.add(user);
            }
        } catch (IOException e) {
            // Handle file reading errors
            throw new IllegalArgumentException("Error reading file: " + e.getMessage());
        }

        return list;
    }
}

public class Booking {
    private Room room;
    private WaitingList waitingList;
    private Printer printer;

    // Constructor
    public Booking(Room room, WaitingList waitingList, Printer printer) {
        this.room = room;
        this.waitingList = waitingList;
        this.printer = printer;
    }

    // Books a room for a user
    public void setBooking(User user) {
        // Validate user input
        if (user == null || user.getName() == null || user.getMemberType() == null) {
            throw new IllegalArgumentException("User details input is null!!!");
        }

        String roomType = getRoomType(user.getMemberType());

        // Handle special case for normal users with rewards
        if (user.getMemberType().equals("normal") && user.getReward()) {
            if (room.checkRoom("VIP")) {
                roomType = "VIP";
                user.setReward(false);
            }
        }

        // Check if the room is available
        boolean roomAvailable = room.checkRoom(roomType);

        if (roomAvailable) {
            // Book the room and print booking info
            room.bookRoom(roomType);
            printer.printInfo(user.getName(), user.getMemberType(), roomType);
        } else {
            // Add user to waiting list if room is not available
            waitingList.addWaitingList(user);
            System.out.println("Room not available. Added to waiting list.");
        }
    }

    // Cancels booking for a user
    public void cancelBooking(User user) {
        // Validate user input
        if (user == null || user.getName() == null || user.getMemberType() == null) {
            throw new IllegalArgumentException("User details input is null!!!");
        }

        String roomType = getRoomType(user.getMemberType());
        // Cancel booking and remove user from waiting list
        room.cancelBooking(roomType);
        waitingList.removeWaitingList(user);
        System.out.println("Booking cancelled successfully.");
    }

    // Get the room type based on user's membership type
    public String getRoomType(String userType) {
        // Validate user input
        if (userType == null) {
            throw new IllegalArgumentException("User type is null!");
        }
        // Determine room type based on membership type
        switch (userType) {
            case "VIP":
                return "VIP";
            case "normal":
                return "Deluxe";
            default:
                return "Standard";
        }
    }

    // Assign random rewards to users
    public static void randomSetRewards(ArrayList<User> userList) {
        // Validate user list
        if (userList == null) {
            throw new IllegalArgumentException("User list is null!");
        }

        Random random = new Random();

        for (User user : userList) {
            // Validate user input
            if (user == null || user.getMemberType() == null) {
                throw new IllegalArgumentException("User details input is null!!!");
            }
            // Assign reward to normal users randomly
            if (user.getMemberType().equals("normal") && random.nextInt(1000) % 7 == 0) {
                user.setReward(true);
            }
        }
    }

    // Search for a user in the user list
    public static int searchUser(ArrayList<User> userList, String name) {
        // Validate user list and name
        if (userList == null || name == null) {
            throw new IllegalArgumentException("User list or name is null!");
        }

        // Search for the user by name
        for (int i = 0; i < userList.size(); i++) {
            if (userList.get(i) != null && userList.get(i).getName() != null && userList.get(i).getName().equals(name)) {
                return i;
            }
        }
        return -1;
    }

   
    // Add users to the waiting list
    public void addToWaitingList(ArrayList<User> userList) {
        // Validate user list
        if (userList == null) {
            System.out.println("User list is null! No users added to the waiting list.");
            return; 
        }
        // Add each user to the waiting list
        for (User user : userList) {
            // Validate user input
            if (user == null || user.getName() == null || user.getMemberType() == null) {
                throw new IllegalArgumentException("User details input is null!!!");
            }
            waitingList.addWaitingList(user);
        }
    }


    // RUN HERE, Main method
    public static void main(String[] args) {
        // Create room, waiting list, printer, and booking objects
        Room room = new Room();
        WaitingList waitingList = new WaitingList();
        Printer printer = new Printer();
        Booking booking = new Booking(room, waitingList, printer);

        // Initialize user list and file object
        ArrayList<User> userList = new ArrayList<>();
        File file = new File("userData.txt");

        // Check if the file exists
        if (file.exists()) {
            // Read user data from the file
            FileReaderClass frc = new FileReaderClass();
            userList = frc.readFile(file);
            if (userList != null) {
                // Assign random rewards to users and add them to waiting list
                randomSetRewards(userList);
                booking.addToWaitingList(userList);

                // Set booking for each user in the list
                for (User user : userList) {
                    booking.setBooking(user);
                }
            } else {
                throw new IllegalArgumentException("Failed to read user data from the file.");
            }
        } else {
            throw new IllegalArgumentException("File not found!!");
        }
    }
}

