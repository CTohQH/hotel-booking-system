package my.edu.utar;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class BookingTest
	{
		private Booking booking;
		private Room room;
		private WaitingList waitingList;
		private Printer printer;
		

		//initialise it
		@Before
		public void setUp() 
		{
			// Create mock objects for Room, WaitingList, and Printer
	        room = mock(Room.class);
	        waitingList = mock(WaitingList.class);
	        printer = mock(Printer.class);

	        // Create Booking object with mock dependencies
	        booking = new Booking(room, waitingList, printer);
	    }
		
		//test case for setBooking for room available for vip
	    @Test
	    public void testSetBookingForRoomAvailableForVIP() {
	        // Create a mock User object
	        User user = mock(User.class);

	        // Set up mock behavior for user
	        when(user.getName()).thenReturn("John");
	        when(user.getMemberType()).thenReturn("VIP");
	        when(user.getReward()).thenReturn(false);
	        when(room.checkRoom("VIP")).thenReturn(true);

	        // Call the method to be tested
	        booking.setBooking(user);

	        // Verify that the room was booked and info was printed
	        verify(room).bookRoom("VIP");
	        verify(printer).printInfo("John", "VIP", "VIP");

	        // Verify that the user was not added to waiting list
	        verify(waitingList, never()).addWaitingList(user);
	    }
	    
	    //test case for setBooking for room availabel for member with reward
	    @Test
	    public void testSetBookingForRoomAvailableForNormalWithReward() {
	        // Create a mock User object
	        User user = mock(User.class);

	        // Set up mock behavior for user
	        when(user.getName()).thenReturn("George");
	        when(user.getMemberType()).thenReturn("normal");
	        when(user.getReward()).thenReturn(true);

	        // Set up mock behavior for room availability
	        when(room.checkRoom("VIP")).thenReturn(true);

	        // Call the method to be tested
	        booking.setBooking(user);

	        // Verify that the room was booked as VIP and reward was reset
	        verify(room).bookRoom("VIP");
	        verify(user).setReward(false);
	        verify(printer).printInfo("George", "normal", "VIP");
	    }

	    //test case for set booking but room not available
	    @Test
	    public void testSetBookingForRoomNotAvailable() {
	        // Create a mock User object
	        User user = mock(User.class);

	        // Set up mock behavior for user
	        when(user.getName()).thenReturn("Bob");
	        when(user.getMemberType()).thenReturn("Deluxe");

	        // Set up mock behavior for room availability
	        when(room.checkRoom("Deluxe")).thenReturn(false);

	        // Call the method to be tested
	        booking.setBooking(user);

	        // Verify that the user was added to waiting list
	        verify(waitingList).addWaitingList(user);

	        // Verify that room was not booked and info was not printed
	        verify(room, never()).bookRoom(anyString());
	        verify(printer, never()).printInfo(anyString(), anyString(), anyString());
	    }

	    //Test case for setBooking for Null user
	    @Test(expected = IllegalArgumentException.class)
	    public void testSetBookingForNullUser() {
	        // Call the method with null user, should throw IllegalArgumentException
	        booking.setBooking(null);
	    }
	    
	    //Test case for cancelBooking
	    @Test
	    public void testCancelBookingSuccess() {
	        // Create a mock User object
	        User user = mock(User.class);

	        // Set up mock behavior for user
	        when(user.getName()).thenReturn("Charlie");
	        when(user.getMemberType()).thenReturn("Standard");

	        // Call the method to be tested
	        booking.cancelBooking(user);

	        // Verify that the room booking was canceled and user removed from waiting list
	        verify(room).cancelBooking("Standard");
	        verify(waitingList).removeWaitingList(user);
	        // No printing should occur in this case
	        verify(printer, never()).printInfo(anyString(), anyString(), anyString());
	    }
	    

	    //test case for cancelbooking for null user
	    @Test(expected = IllegalArgumentException.class)
	    public void testCancelBookingForNullUser() {
	       
	        booking.cancelBooking(null);
	    }

	    //Test case for cancelBooking for null username 
	    @Test(expected = IllegalArgumentException.class)
	    public void testCancelBooking_NullUserName() {
	        // Create a mock User object with null name
	        User user = mock(User.class);
	        when(user.getName()).thenReturn(null);

	        booking.cancelBooking(user);
	    }

	    //Test case for cancel Booking for null user member type
	    @Test(expected = IllegalArgumentException.class)
	    public void testCancelBooking_NullUserMemberType() {
	        // Create a mock User object with null member type
	        User user = mock(User.class);
	        when(user.getMemberType()).thenReturn(null);
	        
	        booking.cancelBooking(user);
	    }

	    //test for vip,member and non member
	    @Test
	    public void testGetRoomType() {
	        // Test VIP 
	    	String ER1 = booking.getRoomType("VIP");
	    	String AR1 = "VIP"; 
	        assertEquals(AR1, ER1);

	        // Test normal member 
	        String ER2 = booking.getRoomType("normal");
	        String AR2 = "Deluxe";
	        assertEquals(AR2,ER2);

	        // Test non-member 
	        String ER3 = booking.getRoomType("non");
	        String AR3 = "Standard";
	        assertEquals(AR3,ER3);
	    }

	    //test case for get room type for null user type
	    @Test(expected = IllegalArgumentException.class)
	    public void testGetRoomTypeForNullUserType() 
	    {
	        booking.getRoomType(null);
	    }

	    //test case for randomsetreward for null userlist
	    @Test(expected = IllegalArgumentException.class)
	    public void testRandomSetRewardsForNullUserList() 
	    {
	        Booking.randomSetRewards(null);
	    }

	  //Test case for randomsetReward
	    @Test
	    public void testRandomSetRewards() 
	    {
	        // Create a mock user list
	        ArrayList<User> userList = new ArrayList<>();
	        User user1 = mock(User.class);
	        User user2 = mock(User.class);
	        User user3 = mock(User.class);

	        // Set up mock behavior for user reward status
	        when(user1.getMemberType()).thenReturn("normal");
	        when(user1.getReward()).thenReturn(true);

	        when(user2.getMemberType()).thenReturn("VIP");
	        when(user2.getReward()).thenReturn(false);

	        when(user3.getMemberType()).thenReturn("normal");
	        when(user3.getReward()).thenReturn(true);

	        userList.add(user1);
	        userList.add(user2);
	        userList.add(user3);
	        
	        // Call the method to set rewards
	        Booking.randomSetRewards(userList);
	        
	        boolean ER1=true;
	        boolean ER2=false;
	        
	        boolean AR1=user1.getReward();
	        boolean AR2=user2.getReward();
	        boolean AR3=user3.getReward();

	        // Verify that rewards were set to true for normal users
	        assertEquals(ER1, AR1);
	        assertEquals(ER1, AR3);

	        // Verify that reward remains unchanged for VIP user
	        assertEquals(ER2, AR2);
	    }


	    //test case for search user for null user list
	    @Test(expected = IllegalArgumentException.class)
	    public void testSearchUser_NullUserList() 
	    {
	        Booking.searchUser(null, "John");
	    }

	    //test case for search user for null user name
	    @Test(expected = IllegalArgumentException.class)
	    public void testSearchUser_NullUserName() 
	    {
	        ArrayList<User> userList = new ArrayList<>();

	        Booking.searchUser(userList, null);
	    }

	    //test case for search user for user not found
	    @Test
	    public void testSearchUser_UserNotFound() {
	        // Create a mock user list
	        ArrayList<User> userList = new ArrayList<>();
	        User user1 = mock(User.class);
	        User user2 = mock(User.class);

	        // Set up mock behavior for user names
	        when(user1.getName()).thenReturn("Alice");
	        when(user2.getName()).thenReturn("Bob");

	        userList.add(user1);
	        userList.add(user2);

	        int AR = Booking.searchUser(userList, "Charlie");
	        int ER = -1;

	        
	        assertEquals(ER, AR);
	    }

	    //Test case  for search user with user found
	    @Test
	    public void testSearchUser_UserFound() {
	        // Create a mock user list
	        ArrayList<User> userList = new ArrayList<>();
	        User user1 = mock(User.class);
	        User user2 = mock(User.class);

	        // Set up mock behavior for user names
	        when(user1.getName()).thenReturn("Alice");
	        when(user2.getName()).thenReturn("Bob");

	        userList.add(user1);
	        userList.add(user2);

	        int AR = Booking.searchUser(userList, "Bob");
	        int ER = 1;
	        assertEquals(ER, AR);
	    }

	    //TEST CASE FOR ADD TO WAITING LIST FOR NULL USERLIST
	    @Test(expected = IllegalArgumentException.class)
	    public void testAddToWaitingList_NullUserList() 
	    {
	    	ArrayList<User> userList = new ArrayList<>();
	    	User user1 = mock(User.class);
	    	user1= null;
	    	userList.add(user1);
	    	
	    	 
	        booking.addToWaitingList(userList);
	    }
	  //TEST CASE FOR ADDTOWAITINGLIST
	    @Test
	    public void testAddToWaitingList() 
	    {
	        // Create a mock user list
	        ArrayList<User> userList = new ArrayList<>();
	        User user1 = mock(User.class);
	        User user2 = mock(User.class);
	        
	        when(user1.getName()).thenReturn("Adam");
	        when(user2.getName()).thenReturn("Eve");
	        
	        when(user1.getMemberType()).thenReturn("VIP");
	        when(user2.getMemberType()).thenReturn("member");
	      


	        userList.add(user1);
	        userList.add(user2);

	        // Call the method to add users to waiting list
	        booking.addToWaitingList(userList);

	        // Verify that addWaitingList is called for each user in the list
	        verify(waitingList, times(1)).addWaitingList(user1);
	        verify(waitingList, times(1)).addWaitingList(user2);
	    }

}
